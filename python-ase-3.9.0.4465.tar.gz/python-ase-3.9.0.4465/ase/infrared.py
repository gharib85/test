from vibrations.infrared import InfraRed
