.. module:: ase.parallel

=====================
Parallel calculations
=====================

.. autofunction:: paropen

.. autofunction:: parprint
