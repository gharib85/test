# creates lmp_atoms lmp_opls lmp_in

exec(compile(open('write_lammps.py').read(), 'write_lammps.py', 'exec'))
