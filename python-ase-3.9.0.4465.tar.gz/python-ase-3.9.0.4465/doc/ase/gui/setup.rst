.. module:: setup

=====
Setup
=====

The setup menus allow for the intuitive creation of numerous standard
surfaces, nanoparticles, graphene and graphene nanoribbons, as well as
nanotubes. 

Along with creating the geometry within ase-gui, a button provides the
necessary python code allowing one to recreate the exact same geometry
in ASE scripts. 
