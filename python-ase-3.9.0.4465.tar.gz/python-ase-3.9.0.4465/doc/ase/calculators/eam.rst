.. module:: ase.calculators.eam

===
EAM
===


.. include:: ../../../ase/calculators/eam.py
   :encoding: utf-8
   :start-after: EAM Interface Documentation
   :end-before: End EAM Interface Documentation


Example:
========

.. literalinclude:: ../../../ase/test/eam_test.py
