.. autoclass:: ase.calculators.cp2k.CP2K
