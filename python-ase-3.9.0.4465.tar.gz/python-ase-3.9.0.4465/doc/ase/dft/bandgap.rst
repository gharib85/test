.. module:: ase.dft.bandgap
   :synopsis: Band gap

========
Band gap
========

.. autofunction:: get_band_gap
