# creates: Ag-eos.png
exec(compile(open('eos1.py').read(), 'eos1.py', 'exec'))
exec(compile(open('eos2.py').read(), 'eos2.py', 'exec'))
