print(sg)
