To do
=====

Check our `issue tracker`_.

.. _issue tracker: http://trac.fysik.dtu.dk/projects/ase/report/1


Documentation
-------------

* Put example of Verlet dynamics in ase/md
* talk about writing files - pos, py and pckl
* Write more about the parameters of the supported elements of the EMT
  calculator.


Code
----

* Could the *directions* argument of ase.lattice.FaceCenteredCubic etc.
  have default values?


