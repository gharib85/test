Python 3 strategy
=================

* One codebase for both 2 and 3.

* Use ``print(...)`` and add this line as the fist line::

    from __future__ import print_function

* Don't do this: ``print >> f, ...``.  Use ``f.write(... + '\n')`` or
  ``print(..., file=f)``.

* More help here: http://packages.python.org/six/
